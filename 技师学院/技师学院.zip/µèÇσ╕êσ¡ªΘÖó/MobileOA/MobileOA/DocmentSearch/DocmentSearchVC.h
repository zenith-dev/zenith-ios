//
//  DocmentSearchVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/5.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface DocmentSearchVC : BaseViewController
@property (nonatomic,strong)NSString *type;//014  公文查询 015 历史库查询
@end
