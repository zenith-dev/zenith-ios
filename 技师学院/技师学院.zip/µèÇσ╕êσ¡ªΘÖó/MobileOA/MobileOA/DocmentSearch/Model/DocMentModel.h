//
//  DocMentModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/6.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DocMentModel : NSObject
@property (nonatomic, strong) NSString * chrgwbt;
@property (nonatomic, strong) NSString * chrgwz;
@property (nonatomic, strong) NSString * chrlwdwmc;
@property (nonatomic, strong) NSString * chrlzlx;
@property (nonatomic, strong) NSString * dtmbjsj;
@property (nonatomic, strong) NSString * dtmblsx;
@property (nonatomic, strong) NSString * dtmfssj;
@property (nonatomic, strong) NSString * dtmrq;
@property (nonatomic, assign) long intgwlsh;
@property (nonatomic, assign) long intgwlzlsh;
@property (nonatomic, assign) long intgwnh;
@property (nonatomic, assign) long intgwqh;
@property (nonatomic, assign) long strbjbz;


@end
