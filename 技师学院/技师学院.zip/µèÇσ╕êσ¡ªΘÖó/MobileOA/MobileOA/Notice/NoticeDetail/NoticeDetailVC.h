//
//  NoticeDetailVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/28.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"
@interface NoticeDetailVC : BaseViewController
@property (nonatomic,assign)int type;
@property (nonatomic, copy) void (^callback)(BOOL issu);
@property (nonatomic,strong)NSString *inttzlsh;
@property (nonatomic,strong)NSString *intgglsh;
@end
