//
//  TzModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/28.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TzModel : NSObject
@property (nonatomic, strong) NSString * dtmdjsj;
@property (nonatomic, assign) long intcs;
@property (nonatomic, assign) long inttzlsh;
@property (nonatomic, assign) long strckbz;
@property (nonatomic, strong) NSString * strdwjc;
@property (nonatomic, strong) NSString * strqfr;
@property (nonatomic, strong) NSString * strryxm;
@property (nonatomic, strong) NSString * strtzbt;
@property (nonatomic, assign) long strzdbz;
@end
