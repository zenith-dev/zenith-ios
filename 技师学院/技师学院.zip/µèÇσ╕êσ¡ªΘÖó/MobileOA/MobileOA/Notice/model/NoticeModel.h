//
//  NoticeModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/28.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NoticeModel : NSObject
@property (nonatomic, strong) NSString * dtmfbrq;
@property (nonatomic, strong) NSString * dtmsxsj;
@property (nonatomic, assign) long intgglsh;
@property (nonatomic, assign) long strcdbz;
@property (nonatomic, strong) NSString * strdwjc;
@property (nonatomic, strong) NSString * strggbt;
@property (nonatomic, strong) NSString * strryxm;

@end
