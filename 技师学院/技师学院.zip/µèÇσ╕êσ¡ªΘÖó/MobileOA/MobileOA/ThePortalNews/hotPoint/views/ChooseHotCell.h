//
//  ChooseHotCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/15.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseHotCell : UICollectionViewCell
@property (nonatomic,strong)UIImageView *iconImageView;
@property (nonatomic,strong)UIColor *bgColor;
@property (nonatomic,strong)UILabel *titlelb;
@property (nonatomic,strong)UILabel *numlb;
@end
