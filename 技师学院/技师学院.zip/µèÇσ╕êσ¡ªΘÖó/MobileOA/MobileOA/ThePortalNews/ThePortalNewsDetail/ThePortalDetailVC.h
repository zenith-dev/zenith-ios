//
//  ThePortalDetailVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/13.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface ThePortalDetailVC : BaseViewController
@property (nonatomic,strong)NSString *news_id;
@end
