//
//  QButton.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/15.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QButton : UIButton

@end
