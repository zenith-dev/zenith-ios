//
//  unitinfo.h
//  MobileOA
//
//  Created by 大熊 on 16/11/24.
//  Copyright © 2016年 dx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Unitinfo : NSObject

@property (nonatomic, assign) long dwccbm;
@property (nonatomic, assign) long intdwlsh;
@property (nonatomic, assign) long intdwlsh_child;
@property (nonatomic, strong) NSString * unitname;
@property (nonatomic, strong) NSString * unitname_child;

@end
