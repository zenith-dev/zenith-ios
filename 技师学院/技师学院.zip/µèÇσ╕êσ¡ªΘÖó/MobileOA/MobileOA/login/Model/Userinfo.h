//
//  userinfo.h
//  MobileOA
//
//  Created by 大熊 on 16/11/24.
//  Copyright © 2016年 dx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Userinfo : NSObject

@property (nonatomic, assign) long intrylsh;
@property (nonatomic, strong) NSString * usergn;
@property (nonatomic, strong) NSString * username;
@property (nonatomic, strong) NSString * userzh;
@property (nonatomic, strong) UIImage * userhaderImg;
@property (nonatomic, assign) NSNumber *strjgsqbz;

@end
