//
//  LoginVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/9/27.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"
@interface LoginVC : BaseViewController

@end
