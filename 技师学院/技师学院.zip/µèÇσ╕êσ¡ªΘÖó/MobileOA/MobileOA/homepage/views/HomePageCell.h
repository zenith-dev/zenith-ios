//
//  HomePageCell.h
//  OAMobileIOS
//
//  Created by 熊佳佳 on 16/9/28.
//  Copyright © 2016年 chenyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageCell : UICollectionViewCell
@property (nonatomic,strong)UIImageView *iconImageView;
@property (nonatomic,strong)UIColor *bgColor;
@property (nonatomic,strong)UILabel *titlelb;
@property (nonatomic,strong)UILabel *numlb;
@end
