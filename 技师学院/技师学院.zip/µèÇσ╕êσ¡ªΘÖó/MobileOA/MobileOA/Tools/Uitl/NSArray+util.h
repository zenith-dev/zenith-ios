//
//  NSArray+util.h
//  tencentTest
//
//  Created by Mao on 16/4/19.
//  Copyright © 2016年 Mao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (util)
-(NSArray*)killNull;
@end
