//
//  LbzbCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/2.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LbzbCell : UITableViewCell
@property (nonatomic,strong)NSDictionary *lbzbdic;
@end
