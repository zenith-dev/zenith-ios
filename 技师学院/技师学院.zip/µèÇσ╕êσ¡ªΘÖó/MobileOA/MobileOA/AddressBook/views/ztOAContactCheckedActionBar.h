//
//  ztOAContactCheckedActionBar.h
//  OAMobileIOS
//
//  Created by 陈杨 on 14-5-16.
//  Copyright (c) 2014年 chenyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ztOAContactCheckedActionBar : UIView
@property(nonatomic,strong)UIImageView      *backImage;
@property(nonatomic,strong)UIButton         *closeBtn;
@property(nonatomic,strong)UILabel          *checkNumberInfo;
@property(nonatomic,strong)UIButton         *loadAllToPhone;
@property(nonatomic,strong)UIButton         *sendMessageToPhone;
@property(nonatomic,strong)UIButton         *cancelCheckedBtn;
@property(nonatomic,strong)UILabel          *loadToPhoneNumLable;
@property(nonatomic,strong)UILabel          *sendMsgNumLable;
@end
