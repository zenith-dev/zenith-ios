//
//  AddUnitInfo.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/29.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddUnitInfo : NSObject
@property (nonatomic, assign) long intdwlsh;
@property (nonatomic, assign) long intpxh;
@property (nonatomic, assign) long strdwccbm;
@property (nonatomic, strong) NSString * strdwcsbz;
@property (nonatomic, strong) NSString * strdwjc;
@property (nonatomic, strong) NSString * strdwjp;
@property (nonatomic, strong) NSString * strdwmc;
@property (nonatomic, strong) NSString * strdwszdz;
@property (nonatomic, strong) NSString * strjgdm;
@property (nonatomic, strong) NSString * strlxdh;
@property (nonatomic, assign) long strnextdwbz;
@property (nonatomic, assign) long strnextrybz;
@property (nonatomic, assign) long stryddh;
@property (nonatomic, strong) NSString * stryzbm;
@end
