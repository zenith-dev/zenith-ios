//
//  AddUserInfo.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/30.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AddUserInfo : NSObject
@property (nonatomic, assign) BOOL selectFlg;//是否选中
@property (nonatomic, strong) NSString * dtmcsrq;
@property (nonatomic, assign) long intpxh;
@property (nonatomic, assign) long intrylsh;
@property (nonatomic, strong) NSString * strbgdh;
@property (nonatomic, strong) NSString * strbgdz;
@property (nonatomic, strong) NSString * strdw;
@property (nonatomic, strong) NSString * strdwcs;
@property (nonatomic, strong) NSString * streMail;
@property (nonatomic, strong) NSString * strryxm;
@property (nonatomic, assign) long strxb;
@property (nonatomic, strong) NSString *stryddh;
@property (nonatomic, strong) NSString * stryhm;
@property (nonatomic, strong) NSString * strzwmc;
@end
