//
//  AddressBookListVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/11/29.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface AddressBookListVC : BaseViewController
@property (nonatomic,strong) NSString *currentCompanylsh;//单位流水号
@end
