//
//  AddressBookDetailVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/1.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"
#import "AddUserInfo.h"
@interface AddressBookDetailVC : BaseViewController
@property (nonatomic,strong)AddUserInfo *adduserInfo;
@end
