//
//  LinkURLVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/8.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface LinkURLVC : BaseViewController
@property (nonatomic,strong)NSString *urlstr;
@end
