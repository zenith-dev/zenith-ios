//
//  ztOADisclaimerViewController.h
//  OAMobileIOS
//
//  Created by 陈杨 on 14-6-3.
//  Copyright (c) 2014年 chenyang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface ztOADisclaimerViewController : BaseViewController

@end
