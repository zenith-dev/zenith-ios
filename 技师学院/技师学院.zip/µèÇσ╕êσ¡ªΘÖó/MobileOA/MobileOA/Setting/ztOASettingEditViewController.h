//
//  ztOASettingEditViewController.h
//  OAMobileIOS
//
//  Created by 陈杨 on 14-4-1.
//  Copyright (c) 2014年 chenyang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface ztOASettingEditViewController : BaseViewController
- (id)initWithTitle:(NSString *)titleStr type:(NSString *)whichType currentStr:(NSString *)currentStr;
@end
