//
//  ztOADisclaimerViewController.m
//  OAMobileIOS
//
//  Created by 陈杨 on 14-6-3.
//  Copyright (c) 2014年 chenyang. All rights reserved.
//

#import "ztOADisclaimerViewController.h"

@interface ztOADisclaimerViewController ()

@end

@implementation ztOADisclaimerViewController

- (id)init
{
    self = [super init ];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}
@end
