//
//  MultRwModel.m
//  MobileOA
//
//  Created by 熊佳佳 on 17/2/10.
//  Copyright © 2017年 xj. All rights reserved.
//

#import "MultRwModel.h"

@implementation MultRwModel

@end
