//
//  MultRwModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 17/2/10.
//  Copyright © 2017年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MultRwModel : NSObject
@property (nonatomic,strong)NSString *rwmc;
@property (nonatomic,strong)NSString *intgzlclsh;
@property (nonatomic,strong)NSMutableArray *xbryAry;
@property (nonatomic,strong)NSMutableDictionary *storeDicts;
@property (nonatomic,strong)NSString *xbrwryxm;
@property (nonatomic,strong)NSDictionary *responsibleManDic;
@property (nonatomic,strong)NSString * zrobj;
@property (nonatomic,strong)NSString *intnewrylshlst;
@property (nonatomic,strong)NSString *intlcdylshlst;
@property (nonatomic,strong)NSString *intbzlst;
@property (nonatomic,strong)NSString *intbcbhlst;
@property (nonatomic,strong)NSString *strzrrlxLst;
@property (nonatomic,strong)NSString *intgzlclshlst;

@end
