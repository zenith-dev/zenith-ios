//
//  DocMentCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/8.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DocToDoModel.h"
@interface DocMentCell : UITableViewCell
@property (nonatomic,strong)DocToDoModel *doctodoModel;
@property (nonatomic,strong)DocToDoModel *doctodoModel2;
@end
