//
//  DocToDoModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/8.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DocToDoModel : NSObject
@property (nonatomic, assign) BOOL isflag;
@property (nonatomic, strong) NSNumber * chrckbz;
@property (nonatomic, strong) NSString * chrdjrcsmc;
@property (nonatomic, strong) NSString * chrfsrxm;
@property (nonatomic, strong) NSString * chrfwdwmc;
@property (nonatomic, strong) NSString * chrgwbt;
@property (nonatomic, strong) NSString * chrgwz;
@property (nonatomic, strong) NSString * chrgzrwmc;
@property (nonatomic, strong) NSString * chrhjcd;
@property (nonatomic, strong) NSString * chrlwdwmc;
@property (nonatomic, strong) NSString * chrlzlx;
@property (nonatomic, strong) NSString * chrmj;
@property (nonatomic, strong) NSString * dtmblsx;
@property (nonatomic, strong) NSString * dtmfssj;
@property (nonatomic, strong) NSNumber * intbzjllsh;
@property (nonatomic, strong) NSNumber * intcstsblsx;
@property (nonatomic, strong) NSNumber * intfsrylsh;
@property (nonatomic, strong) NSNumber * intgwlsh;
@property (nonatomic, strong) NSNumber * intgwlzlsh;
@property (nonatomic, strong) NSNumber * intgwnh;
@property (nonatomic, strong) NSNumber * intgwqh;
@property (nonatomic, strong) NSNumber * sgcsts;
@property (nonatomic, strong) NSNumber * strbjbz;
@end
