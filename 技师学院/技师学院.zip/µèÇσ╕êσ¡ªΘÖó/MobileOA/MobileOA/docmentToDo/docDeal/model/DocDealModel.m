//
//  DocDealModel.m
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/9.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "DocDealModel.h"

@implementation DocDealModel

@end
