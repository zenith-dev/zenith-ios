//
//  ThePortalList.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/12.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface ThePortalList : BaseViewController
@property (nonatomic,strong)UINavigationController *navs;
@property (nonatomic,strong)NSString *channelid;
@property (nonatomic,strong)NSString *category_id;
@property (nonatomic,strong)UITableView *theportTb;
-(void)getDatas:(BOOL)isup;
@end
