//
//  PlanListDocModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 17/4/12.
//  Copyright © 2017年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlanListDocModel : NSObject
@property (nonatomic, strong) NSString * dtmfbrq;
@property (nonatomic, strong) NSNumber * intwdwjlsh;
@property (nonatomic, strong) NSString * strdjrxm;
@property (nonatomic, strong) NSString * strdwjc;
@property (nonatomic, strong) NSNumber * strgxbz;
@property (nonatomic, strong) NSString * strwdbt;
@end
