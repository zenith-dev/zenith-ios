//
//  PlanListCCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 17/4/12.
//  Copyright © 2017年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlanListDocModel.h"
@interface PlanListCCell : UITableViewCell
@property (nonatomic,strong)PlanListDocModel *planmodel;
@end
