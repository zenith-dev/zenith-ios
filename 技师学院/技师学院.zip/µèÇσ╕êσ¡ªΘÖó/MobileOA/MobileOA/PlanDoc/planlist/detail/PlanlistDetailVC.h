//
//  PlanlistDetailVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 17/4/12.
//  Copyright © 2017年 xj. All rights reserved.
//

#import "BaseViewController.h"
#import "PlanListDocModel.h"
@interface PlanlistDetailVC : BaseViewController
@property (nonatomic,strong)PlanListDocModel *planlistdocmodel;
@end
