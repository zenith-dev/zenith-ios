//
//  PlanDocCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 17/4/12.
//  Copyright © 2017年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlanModel.h"
@interface PlanDocCell : UITableViewCell
@property (nonatomic,strong)PlanModel *planmodel;
@end
