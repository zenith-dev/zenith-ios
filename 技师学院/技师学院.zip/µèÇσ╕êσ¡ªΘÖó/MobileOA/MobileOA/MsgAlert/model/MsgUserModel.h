//
//  MsgUserModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/6.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MsgUserModel : NSObject
@property (nonatomic, strong) NSString * intdwpxh;
@property (nonatomic, strong) NSString * intrylsh;
@property (nonatomic, strong) NSString * intrypxh;
@property (nonatomic, strong) NSString * strbgdh;
@property (nonatomic, strong) NSString * strdw;
@property (nonatomic, strong) NSString * strdwcs;
@property (nonatomic, strong) NSString * strxm;
@property (nonatomic, strong) NSString * stryddh;
@property (nonatomic, strong) NSString * strzw;
@end
