//
//  CharModel.m
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/7.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "CharModel.h"

@implementation CharModel

@end
