//
//  CharModel.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/7.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CharModel : NSObject
@property (nonatomic, strong) NSString * bz;
@property (nonatomic, strong) NSString * dtmfssj;
@property (nonatomic, strong) NSNumber * intchatlsh;
@property (nonatomic, strong) NSNumber * intfsrlsh;
@property (nonatomic, strong) NSNumber * intjsrlsh;
@property (nonatomic, strong) NSString * strfsrxm;
@property (nonatomic, strong) NSString * strjsrxm;
@property (nonatomic, strong) NSString * strnr;
@end
