//
//  MsgUserCell.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/6.
//  Copyright © 2016年 xj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MsgUserModel.h"
@interface MsgUserCell : UITableViewCell
@property (nonatomic,strong)MsgUserModel *msguserModel;
@end
