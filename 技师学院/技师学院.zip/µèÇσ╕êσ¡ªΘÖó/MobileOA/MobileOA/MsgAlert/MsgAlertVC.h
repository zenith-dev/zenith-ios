//
//  MsgAlertVC.h
//  MobileOA
//
//  Created by 熊佳佳 on 16/12/6.
//  Copyright © 2016年 xj. All rights reserved.
//

#import "BaseViewController.h"

@interface MsgAlertVC : BaseViewController

@end
